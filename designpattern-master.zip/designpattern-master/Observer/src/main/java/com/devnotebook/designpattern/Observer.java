package com.devnotebook.designpattern;

public interface Observer {

    void update();
}
