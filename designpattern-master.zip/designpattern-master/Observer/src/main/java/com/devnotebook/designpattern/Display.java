package com.devnotebook.designpattern;

public interface Display {
    void display();
}
